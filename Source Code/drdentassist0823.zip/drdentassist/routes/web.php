<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('pages.one');
});*/

Route::get('/', 'PagesController@index');
Route::get('/about', 'PagesController@about');
Route::get('/services', 'PagesController@services');
Route::get('/contactus', 'PagesController@contact');
Route::get('/derma', 'PagesController@derma');
Route::get('/dental', 'PagesController@dental');
Route::get('/pages/appointment', 'PagesController@appointment');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['prefix' => 'admin', 'namespace' => 'Admin'], function () {
    Route::get('/', 'Auth\LoginController@showLoginForm');
    Route::post('login', 'Auth\LoginController@login')->name('admin.login');
    Route::post('logout', 'Auth\LoginController@logout')->name('admin.logout');
    Route::get('register', 'Auth\RegisterController@showRegistrationForm');
    Route::post('register', 'Auth\RegisterController@register')->name('admin.register');
    Route::get('home', 'HomeController@index');
});

Route::group(['prefix' => 'doctor', 'namespace' => 'Doctor'], function () {
    Route::get('/', 'Auth\LoginController@showLoginForm');
    Route::post('login', 'Auth\LoginController@login')->name('doctor.login');
    Route::post('logout', 'Auth\LoginController@logout')->name('doctor.logout');
    Route::get('register', 'Auth\RegisterController@showRegistrationForm');
    Route::post('register', 'Auth\RegisterController@register')->name('doctor.register');
    Route::get('home', 'HomeController@index');
});

Route::match(array('GET', 'POST'), '/book', function()
{
    return view('pages/book');
});

Route::get('/time', function () {
    return view('schedules.timepicker');
});

/*Route::match(array('GET', 'POST'), '/schedules/edit', function()
{
    return view('schedules/edit');
});*/

Route::resource('schedules', 'SchedulesController');
