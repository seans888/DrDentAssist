<?php $__env->startSection('content'); ?>
<div class ="container">
	<h1>Create Doctor Schedule</h1>
	<?php echo Form::open(['action' => 'SchedulesController@store', 'method' => 'POST']); ?>

	<table>
		<tr>
				<div class="form-group">
					<?php echo e(Form::label('doctor_id', 'Select Doctor')); ?>

					<?php echo e(Form::select('doctor_id', $doctors, ['class' => 'form-control'])); ?>

				</div>
		
		
			<th>
				<div class="form-group">
				   <?php echo e(Form::label('days_of_the_week', 'Pick a Day')); ?>

					<?php echo e(Form::select('days_of_the_week', [
					'Monday' => 'Monday',
					'Tuesday' => 'Tuesday',
					'Wednesday' => 'Wednesday',
					'Thursday' => 'Thursday',
					'Friday' => 'Friday',
					'Saturday' => 'Saturday']
					)); ?>

				</div>
			</th>
			
			<tr>
				<th>
					<div>

						<strong>start time:</strong>

						<input name = "start_time" class="timepicker form-control" type="text">
					</div>
				</th>
				<th><strong><TBODY></TBODY></strong></th>
				<th>
					<div>
						<strong>end time:</strong>
						<input name = "end_time" class="timepicker form-control" type="text">
					</div>
				</th>
			</tr>
				<!--<th>
					<div class="form-group">
						<?php echo e(Form::label('start_time', 'Start Time')); ?>

						<?php echo e(Form::select('start_time', [ 
						'8:00:00' => '8 AM',
						'9:00:00' => '9 AM',
						'10:00:00' => '10 AM',
						'11:00:00' => '11 AM',
						'12:00:00' => '12 NN',
						'13:00:00' => '1 PM',
						'14:00:00' => '2 PM',
						'15:00:00' => '3 PM',
						'16:00:00' => '4 PM',
						'17:00:00' => '5 PM',
						'18:00:00' => '6 PM'
						] )); ?>

					</div>
				</th>
				<th>
					<div class="form-group">
						<?php echo e(Form::label('end_time', 'End Time')); ?>

						{Form::select('end_time', [
						'9:00:00' => '9 AM',
						'10:00:00' => '10 AM',
						'11:00:00' => '11 AM',
						'12:00:00' => '12 NN',
						'13:00:00' => '1 PM',
						'14:00:00' => '2 PM',
						'15:00:00' => '3 PM',
						'16:00:00' => '4 PM',
						'17:00:00' => '5 PM',
						'18:00:00' => '6 PM'
						] ) }}-->
					</div>
				</th>
			</tr>
		</td>
	</table>
		
	  <?php echo e(Form::submit('Add', ['class'=>'btn btn-primary'])); ?>	
	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>