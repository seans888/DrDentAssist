<?php $__env->startSection('content'); ?>
<div class = "container">
<h1>Schedules</h1>

<?php if(count($schedules) > 0): ?>
	<?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="well">
		<h3><?php echo e($schedule->doctor->name); ?></h3>
		<h3><?php echo e($schedule->days_of_the_week); ?></h3>
		<small>Days Avail <?php echo e($schedule->days_of_the_week); ?> start_time <?php echo e($schedule->start_time); ?> end_time<?php echo e($schedule->end_time); ?> </small>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<p>No schedules found</p>
<?php endif; ?>
	<table>
	<p>
	<a href="/schedules/create" class="btn btn-primary">Add another entry</a>
	<a href="/schedules/edit" class="btn btn-primary">Edit an entry</a>
	<a href="/admin" class="btn btn-primary">Back to admin page</a>
	<?php echo e($schedules->links()); ?>

	</p>
	</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>