<?php $__env->startSection('content'); ?>
<div class = "container">
	<h1>Edit Schedule</h1>
	<?php echo Form::open(['action' => ['SchedulesController@update', $schedule->schedule],'method' => 'POST']); ?>

		<h3><?php echo e($schedule->doctor->name); ?></h3>
		<div class="form-group">
				   <?php echo e(Form::label('days_of_the_week', 'Edit Day')); ?>

					<?php echo e(Form::select('days_of_the_week', [
					'Monday' => 'Monday',
					'Tuesday' => 'Tuesday',
					'Wednesday' => 'Wednesday',
					'Thursday' => 'Thursday',
					'Friday' => 'Friday',
					'Saturday' => 'Saturday']
					)); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('start_time', 'Start_Time')); ?>

			<?php echo e(Form::text('start_time', $schedule->start_time, ['class' => 'timepicker form-control', 'placeholder' => 'Start Time'])); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('end_time', 'End_Time')); ?>

			<?php echo e(Form::text('end_time', $schedule->end_time, ['class' => 'timepicker form-control', 'placeholder' => 'End Time'])); ?>

		</div>
	   <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>	
	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>