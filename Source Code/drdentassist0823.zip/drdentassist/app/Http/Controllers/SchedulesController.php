<?php

namespace App\Http\Controllers;
use App\Schedule;
use App\Doctor;
use Illuminate\Http\Request;

class SchedulesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
      $schedules = Schedule::all();
      $schedules = Schedule::orderBy('doctor_id','asc')->paginate(2);
      return view('schedules.index',compact('schedules', 'doctors'));
      /**need to display only the doctor_id for that specific input
      */
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $doctors = Doctor::pluck('name', 'doctor_id');
        return view('schedules.create', compact('doctors'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $requests
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $this->validate($request, [
        'days_of_the_week' => 'required',
        'start_time' => 'required',
        'end_time' => 'required'
        ]);

      $schedule = new Schedule;
      $schedule->doctor_id = $request->input('doctor_id');
      $schedule->days_of_the_week = $request->input('days_of_the_week');
      $schedule->start_time = $request->input('start_time');
      $schedule->end_time = $request->input('end_time');
      $schedule->save();

      return redirect('/schedules');
      //->with('success', 'Post Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($schedule_id){
      $schedules =  Schedule::find($schedule_id);
      $schedules = Schedule::orderBy('doctor_id','asc')->paginate(2);
      return view('schedules.show')->with('schedules', $schedules);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $schedule_id
     * @return \Illuminate\Http\Response
     */
    public function edit($schedule)
    {
    $schedule = Schedule::find($schedule);
    return view('schedules.edit')->with ('schedule', $schedule);
        }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $schedule_id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $schedule)
    {
    $this->validate($request, [
    'days_of_the_week' => 'required',
    'start_time' => 'required',
    'end_time' => 'required'
    ]);
    
    $schedule = Schedule::find($schedule);
    $schedule->days_of_the_week = $request->input('days_of_the_week');
    $schedule->start_time = $request->input('start_time');
    $schedule->end_time = $request->input('end_time');
    $schedule = save();
  
  return redirect('/schedules')->with('success', 'Schedule Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($schedule)
    {
    $schedule = Schedule::find($schedule);
    $schedule->delete();
    return redirect('/schedules')->with('success', 'Schedule Removed');
    }
}
