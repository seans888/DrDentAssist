<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index(){
    	return view('pages.one');
    }
 
 	public function about(){
    	return view('pages.about');
    }

    public function services(){
    	return view('pages.services');
    }

    public function contact(){
    	return view('pages.contact');
    }
     public function derma(){
        return view('pages.derma');
    }
    public function dental(){
        return view('pages.dental');
    }
    public function appointment(){
        return view('pages.appointment');
    }
}
