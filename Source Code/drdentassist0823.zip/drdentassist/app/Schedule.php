<?php

namespace App;

use App\Doctor;
use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    protected $fillable = [
        'schedule_id', 'days_of_the_week', 'start_time', 'end_time',
    ];
    public function doctor(){
    	return $this->belongsTo('App\Doctor', 'doctor_id');
    }
    protected $table = "doctor_schedules";
    public $primaryKey = 'schedule_id';
	public $timestamps = true;
}
