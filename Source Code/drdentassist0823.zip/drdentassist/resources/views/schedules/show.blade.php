@extends('admin.layouts.app')

@section('content')
<div class = "container">
<h1>Schedules</h1>

@if(count($schedules) > 0)
	@foreach($schedules as $schedule)
		<div class="well">
		<h3>{{$schedule->doctor->name}}</h3>
		<h3>{{$schedule->days_of_the_week}}</h3>
		<small>Days Avail {{$schedule->days_of_the_week}} start_time {{$schedule->start_time}} end_time{{$schedule->end_time}} </small>
		<hr>
		<a href="/schedules/{{$schedule->schedule_id}}/edit" class="btn btn-success">Edit</a>
		{!!Form::open(['action' => ['SchedulesController@destroy', $schedule], 'method'=> 'POST', 'class' => 'pull-right'])!!}
		{{Form::hidden('_method', 'DELETE')}}
		{{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
		{!!Form::close()!!}
		</div>
		@endforeach
@else
	<p>No schedules found</p>
@endif

	<p>
	<a href="/schedules/create" class="btn btn-primary">Add another entry</a>
	<a href="/admin" class="btn btn-primary">Back to admin page</a>
	{{$schedules->links()}}
	</p>
	</div>


@endsection
