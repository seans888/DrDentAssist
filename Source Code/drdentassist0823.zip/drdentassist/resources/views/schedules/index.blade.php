@extends('admin.layouts.app')

@section('content')
<div class = "container">
<h1>Schedules</h1>

@if(count($schedules) > 0)
	@foreach($schedules as $schedule)
		<div class="well">
		<h3>{{$schedule->doctor->name}}</h3>
		<h3>{{$schedule->days_of_the_week}}</h3>
		<small>Days Avail {{$schedule->days_of_the_week}} start_time {{$schedule->start_time}} end_time{{$schedule->end_time}} </small>
		</div>
		@endforeach
@else
	<p>No schedules found</p>
@endif
	<table>
	<p>
	<a href="/schedules/create" class="btn btn-primary">Add another entry</a>
	<a href="/schedules/edit" class="btn btn-primary">Edit an entry</a>
	<a href="/admin" class="btn btn-primary">Back to admin page</a>
	{{$schedules->links()}}
	</p>
	</div>


@endsection

@extends('layouts.partials._footer')