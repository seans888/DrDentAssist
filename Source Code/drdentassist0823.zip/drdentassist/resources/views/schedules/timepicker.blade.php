<!DOCTYPE html>

<html>

<head>

  <title>Laravel Bootstrap Timepicker</title>

  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>  

</head>


<body>

<div class="container">

    <h1>Laravel Bootstrap Timepicker</h1>

     Pick a Day<br>
    Monday <input name = "days_of_the_week" type="checkbox"> 
    Tuesday <input name = "days_of_the_week" type="checkbox"> 
    Wednesday <input name = "days_of_the_week" type="checkbox"> 
    Thursday <input name = "days_of_the_week" type="checkbox"> 
    Friday <input name = "days_of_the_week" type="checkbox"> 
    Saturday <input name = "days_of_the_week" type="checkbox"> 

   
      <div>

      <strong>start time:</strong>
     
      <input name = "start_time" class="timepicker form-control" type="text">
    </div>
    <div>
      <strong>end time:</strong>
      <input name = "end_time" class="timepicker form-control" type="text">
       </div>
  

<a href="" class="btn btn-primary" id="addsched">Submit</a>

</div>

<script type="text/javascript">

    $('.timepicker').datetimepicker({

        format: 'HH:mm'

    }); 
</script>  

</body>

</html>