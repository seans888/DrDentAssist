This containsthe doctor's appointment.
Let's implement a Full Calendar on this.