@extends('layouts.app')

@section('content')
<div class ="container">
    <h1>Booking Form</h1>
    
    <table>
        <tr>
                <th>
                    <div>

                        <strong>Select a Doctor</strong>

                        <input name = "selected_doctor" class="form-control" type="text">
                    </div>
                </th>

               

                <th>
                    <strong> OR </strong>
                </th>

                               
                <th>
                    <div>

                        <strong>Select a Service</strong>

                        <input name = "selected_service" class="datepicker form-control" type="text">
                    </div>
                </th>
            </tr>
                         
            <tr>
                <th>
                    <div>

                        <strong>Pick a Date</strong>

                        <input name = "selected_date" class="datepicker form-control" type="text">
                    </div>
                </th>

                <th>
                    <div>

                        <strong>Availabe Schedules:</strong>

                        <input name = "available_time_slots" class="timepicker form-control" type="text">
                    </div>
                </th>
                
                 <th>
                    <div>

                        <strong>Pick your time:</strong>

                        <input name = "selected_time_slot" class="form-control" type="text">
                    </div>
                </th>

            </tr>
                <!--<th>
                    <div class="form-group">
                        {{Form::label('start_time', 'Start Time') }}
                        {{Form::select('start_time', [ 
                        '8:00:00' => '8 AM',
                        '9:00:00' => '9 AM',
                        '10:00:00' => '10 AM',
                        '11:00:00' => '11 AM',
                        '12:00:00' => '12 NN',
                        '13:00:00' => '1 PM',
                        '14:00:00' => '2 PM',
                        '15:00:00' => '3 PM',
                        '16:00:00' => '4 PM',
                        '17:00:00' => '5 PM',
                        '18:00:00' => '6 PM'
                        ] ) }}
                    </div>
                </th>
                <th>
                    <div class="form-group">
                        {{Form::label('end_time', 'End Time')}}
                        {Form::select('end_time', [
                        '9:00:00' => '9 AM',
                        '10:00:00' => '10 AM',
                        '11:00:00' => '11 AM',
                        '12:00:00' => '12 NN',
                        '13:00:00' => '1 PM',
                        '14:00:00' => '2 PM',
                        '15:00:00' => '3 PM',
                        '16:00:00' => '4 PM',
                        '17:00:00' => '5 PM',
                        '18:00:00' => '6 PM'
                        ] ) }}-->
                    </div>
                </th>
            </tr>
        </td>
    </table>
 
</div>
@endsection
