@extends('layouts.app')
@section('content')
This is the contact us page.
@endsection