@extends('layouts.app')
@section('content')
This is the services page
@endsection