

@extends('layouts.app')
<div class="container">
 <header class="jumbotron hero-spacer">
            <h1>A Warm Welcome!</h1>
            <p>At Happy Clinique, we are dedicated to providing professional health care to individuals, families and the community.
There’s much more to come! </p>
            <p><a class="btn btn-primary btn-large">Book an appointment with us!</a>
            </p>
        </header>
        
@section('content')

<!-- Title -->
        <div class="row">
            <div class="col-lg-12">
                <h3>Services Offered</h3>
            </div>
        </div>
        <!-- /.row -->

        <!-- Page Features -->
        <div class="row text-center">

            <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="images/derma.jpg" alt="">
                    <div class="caption">
                        <h3>Dermatology</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                            <a href="/book" class="btn btn-primary">Book Now!</a> <a href="/derma" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="images/dental.jpg" alt="">
                    <div class="caption">
                        <h3>Dental</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                            <a href="/book" class="btn btn-primary">Book Now!</a> <a href="/dental" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="images/diag.jpg" alt="">
                    <div class="caption">
                        <h3>Diagnostic Services</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                           <a href="#" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="images/med.jpg" alt="">
                    <div class="caption">
                        <h3>Medical Services</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        <p>
                           <a href="#" class="btn btn-default">More Info</a>
                        </p>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.row -->

        <hr>
@endsection
</div>