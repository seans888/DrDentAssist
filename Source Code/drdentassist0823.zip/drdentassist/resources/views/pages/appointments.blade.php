This contains the patients appointments.
Lets implement a full calendar here.