<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Happy Clinique</title>

    <!-- Styles -->
    
    <!-- Bootstrap Core CSS -->
    
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/jquery.dropdown.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/jquery-ui.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/material-icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

    
    </head>


<body>
    <div id="app">
        <?php echo $__env->make('admin.layouts._adminnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>

    <!-- bootstrap datepicker -->
    <script type="text/javascript" src="<?php echo e(asset('css/moment/min/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('css/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>" ></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css')); ?>" />

    <?php echo $__env->yieldContent('javascripts'); ?>

</body>
<?php echo $__env->make('layouts.partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>