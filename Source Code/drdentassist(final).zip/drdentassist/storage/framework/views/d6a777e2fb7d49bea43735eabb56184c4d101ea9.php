<?php $__env->startSection('content'); ?>

    <!-- start container -->
    <div class="container" role="main">

        <h1>Book A New Appointment</h1>
        <br>

        <?php if(count($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                <span class="sr-only">Error:</span>
                Please review information that you have entered.
            </div>
        <?php endif; ?>

        <!-- start form -->
        <?php echo Form::open(array('method' => 'POST', 'route' => 'bookings.store')); ?>


            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Appointment Information</h3>
                </div>
                <div class="panel-body">

                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('user_id') ? ' has-error' : ''); ?>">
                            <?php if( Auth::check() ): ?>
                            <label class="control-label"> <?php echo e(Auth::user()->name); ?></label>
                            <?php endif; ?>
                            <span class="required-asterisk">*</span>
                            <?php echo Form::hidden('user_id', Auth::user()->id , old('user_id'), array('class' => 'form-control', 'placeholder' => '----')); ?>

                            <?php if($errors->has('user_id')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('user_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('doctor_id') ? ' has-error' : ''); ?>">
                            <label class="control-label">Doctor Name</label>
                            <span class="required-asterisk">*</span>
                            <?php echo Form::select('doctor_id', $doctors->pluck('name','id'), old('doctor_id'), array('class' => 'form-control', 'placeholder' => '----')); ?>

                            <?php if($errors->has('doctor_id')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('doctor_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('service_id') ? ' has-error' : ''); ?>">
                            <label class="control-label">Service Name</label>
                            <span class="required-asterisk">*</span>
                            <?php echo Form::select('service_id', $services->pluck('service_name','id'), old('service_id'), array('class' => 'form-control', 'placeholder' => '----')); ?>

                            <?php if($errors->has('service_id')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('servicer_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('selected_date') ? ' has-error' : ''); ?>">
                            <label class="control-label">Date</label>
                            <span class="required-asterisk"> *</span>
                            <?php echo Form::date('selected_date', old('selected_date'), array('class' => 'form-control', 'placeholder' => 'From')); ?>

                            <?php if($errors->has('selected_date')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('selected_date')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('selected_start_time') ? ' has-error' : ''); ?>">
                            <label class="control-label">Start Time</label>
                            <span class="required-asterisk"> *</span>
                            <?php echo Form::time('selected_start_time', old('selected_start_time'), array('class' => 'form-control', 'placeholder' => 'From')); ?>

                            <?php if($errors->has('selected_start_time')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('selected_start_time')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-lg-12 <?php echo e($errors->has('selected_end_time') ? ' has-error' : ''); ?>">
                            <label class="control-label">End Time</label>
                            <span class="required-asterisk"> *</span>
                            <?php echo Form::time('selected_end_time', old('selected_end_time'), array('class' => 'form-control', 'placeholder' => 'To')); ?>

                            <?php if($errors->has('selected_end_time')): ?>
                                <span class="error">
                                    <strong><?php echo e($errors->first('selected_end_time')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>

            <button type="submit" class="btn btn-raised btn-primary">Save</button>

            <a class="btn btn-raised btn-primary" href="<?php echo e(route('bookings.index')); ?>">Back</a>

        <!-- end form-->
        <?php echo Form::close(); ?>


    <!-- end container -->
    </div>
    <!-- end content block -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>