<?php $__env->startSection('content'); ?>

<table class="table table-hover table-stripped">

		<td>
	<h2>Dra. Nancy Calimag</h2>
	<h4>General Dentistry</h4>
	<p>
		<h3>Schedule</h3>
		<ul>
			<li>Monday</li>
				<ul>8:00 AM to 11:00 AM</ul>
				<ul>3:00 PM to 5:00PM</ul>
			<li>Tuesday</li>
				<ul>1:00 PM to 5:00 PM</ul>
			<li>Saturday</li>
				<ul>10:00 AM to 7:00 PM</ul>
		</ul>
	</p>
	</td>
	<td>
	<h2>Dra. Leticia Aspiras</h2>
	<h4>Orthodontist</h4>
	<p>
		<h3>Schedule</h3>
		<ul>
			<li>Monday</li>
				<ul>5:30 PM to 9:00 PM</ul>
			<li>Friday</li>
				<ul>1:00 PM to 5:00 PM</ul>
			<li>Saturday</li>
				<ul>10:00 AM to 7:00 PM</ul>
		</ul>
	</p>
	</td>
<td>
	<h2>Dra. Elize Estrada</h2>
	<h4>Dermatologist</h4>
	<p>
		<h3>Schedule</h3>
		<ul>
			<li>Monday</li>
				<ul>1:30 PM to 5:00 PM</ul>
			<li>Tuesday</li>
				<ul>1:00 PM to 5:00 PM</ul>
			<li>Wednesday</li>
				<ul>1:00 PM to 5:00 PM</ul>
			<li>Thursday</li>
				<ul>1:00 PM to 5:00 PM</ul>
			<li>Saturday</li>
				<ul>10:00 AM to 7:00 PM</ul>
		</ul>
	</p>
</td>
</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>