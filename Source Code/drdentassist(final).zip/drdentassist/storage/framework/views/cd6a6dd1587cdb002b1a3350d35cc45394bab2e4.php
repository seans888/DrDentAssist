<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Admin Dashboard</div>

                <!-- <div class="panel-body">
                   <p>What do you want to do?</p><br>
                   <p>
                    <ul>
                    <li>
                        Manage User Payments
                        <ul>
                            <a href="#" class="btn btn-primary">Add New Entry</a>
                        </ul>
                        <ul>
                            <a href="#" class="btn btn-primary">View</a>
                        </ul>
                    </li>
                    <li>
                        Manage Doctor Information
                        <ul>
                            <a href="/doctor/specialization" class="btn btn-primary">Add a specialization field</a>
                        </ul>
                        <ul>
                            <a href="/doctor/register" class="btn btn-primary">Provide access to a new doctor</a>
                        </ul>
                        <ul>
                            <a href="/schedules/create " class="btn btn-primary">Manage Doctor's Schedule</a>
                        </ul>
                    </li>
                    <li>
                        Manage Appointments
                        <ul>
                            <a href="/doctor/appoinment" class="btn btn-primary">View Doctor's Appointments</a>
                        </ul>
                        <ul>
                            <a href="/pages/appointment " class="btn btn-primary">View Patient's Appointments</a>
                        </ul>
                    </li>
                   </p>
                </div> -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>