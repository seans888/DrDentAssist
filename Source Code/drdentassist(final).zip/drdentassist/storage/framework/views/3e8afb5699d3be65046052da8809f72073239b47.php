<?php $__env->startSection('content'); ?>


	<div class="container" role="main">
		
		<h1>List of Appointments</h1>

		<?php if(Session::has('message')): ?>
			<div class="alert alert-dismissible alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong><?php echo e(Session::get('message')); ?></strong>
			</div>
		<?php endif; ?>
			
		<table class="table table-hover table-stripped">
			<thead>
				<tr>
					<th>ID</th>
					<th>Patient Name</th>
					<th>Doctor Name</th>
					<th>Service</th>
					<th>Appointment Date</th>
					<th>Appointment Time</th>
					<th style="text-align: center;">Edit</th>
					<th style="text-align: center;">Delete</th>
				</tr>	
			</thead>
			<tbody>
				<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="success">
						<td><?php echo e($appointment->id); ?></td>
						<td><?php echo e($appointment->user->name); ?></td>
						<td><?php echo e($appointment->doctor->name); ?></td>
						<td><?php echo e($appointment->services->service_name); ?></td>
						<td><?php echo e($appointment->selected_date); ?></td>
						<td><?php echo e($appointment->selected_start_time); ?> to <?php echo e($appointment->selected_end_time); ?></td>										
						<td style="text-align: center;"><a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>"><i class="fa fa-edit fa-lg"></a></td>
						<td>
							<?php echo Form::open(array('method' => 'DELETE', 'route' => array('appointments.destroy', $appointment->id))); ?>

								<a href="#" class="delete">
									<center><i class="fa fa-trash fa-lg"></i></center>
								</a>
								<!-- <button class="btn-link btn-primary delete">
									<i class="fa fa-trash fa-lg"></i>
								</button> -->

								<!-- Modal -->
								<div class="modal fade myModal" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Delete Appointment</h4>
											</div>
											<div class="modal-body">
												<div class="container">
													<div class="row">
														Are you sure you want to delete this appointment?
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary">Delete</button>
												<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
											</div>
										</div>

									</div>
								</div>
							<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<?php echo e($appointments->links()); ?>



		<a class="btn btn-raised btn-primary" href="<?php echo e(route('appointments.create')); ?>">Add New</a>

	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>

	<script type="text/javascript">

		$(document).ready(function(){


			$('.delete').click(function(e){

				e.preventDefault();

				$(this).next().modal('show');

			});

			$('.alert-success').fadeTo(2000, 500).slideUp(500, function(){
			    $('.alert-success').slideUp(500);
			});

		});

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>