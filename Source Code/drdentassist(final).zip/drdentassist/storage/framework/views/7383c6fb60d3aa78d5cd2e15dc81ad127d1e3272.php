<?php $__env->startSection('content'); ?>


	<div class="container" role="main">
		
		<h1>List of Specialization</h1>

		<?php if(Session::has('message')): ?>
			<div class="alert alert-dismissible alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong><?php echo e(Session::get('message')); ?></strong>
			</div>
		<?php endif; ?>
			
		<table class="table table-hover table-stripped">
			<thead>
				<tr>
					<th>ID</th>
					<th>NAME</th>
					<th style="text-align: center;">SERVICES</th>
					<th style="text-align: center;">Edit</th>
					<th style="text-align: center;">Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="success">
						<td><?php echo e($specialization->id); ?></td>
						<td><?php echo e($specialization->specialization_name); ?></td>
						<td style="text-align: center;"><a href="<?php echo e(route('services.show', $specialization->service_id)); ?>"><i class="fa fa-medkit fa-lg"></a></td>
						<td style="text-align: center;"><a href="<?php echo e(route('specializations.edit', $specialization->id)); ?>"><i class="fa fa-edit fa-lg"></a></td>
						<td>
							<?php echo Form::open(array('method' => 'DELETE', 'route' => array('specializations.destroy', $specialization->id))); ?>

								<a href="#" class="delete">
									<center><i class="fa fa-trash fa-lg"></i></center>
								</a>
								<!-- <button class="btn-link btn-primary delete">
									<i class="fa fa-trash fa-lg"></i>
								</button> -->

								<!-- Modal -->
								<div class="modal fade myModal" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Delete Specialization</h4>
											</div>
											<div class="modal-body">
												<div class="container">
													<div class="row">
														Are you sure you want to delete this specialization?
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary">Delete</button>
												<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
											</div>
										</div>

									</div>
								</div>
							<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<?php echo e($specializations->links()); ?>



		<a class="btn btn-raised btn-primary" href="<?php echo e(route('specializations.create')); ?>">Add New Specialization</a>

	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>

	<script type="text/javascript">

		$(document).ready(function(){


			$('.delete').click(function(e){

				e.preventDefault();

				$(this).next().modal('show');

			});

			$('.alert-success').fadeTo(2000, 500).slideUp(500, function(){
			    $('.alert-success').slideUp(500);
			});

		});

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>