<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Happy Clinique</title>
	 <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/jquery.dropdown.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/jquery-ui.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/material-icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

</head>
<body id="page-top" class="index">
	<div><img src="<?php echo e(asset('images/hapic.jpg')); ?>" height=75px width=450px display="block" margin="0 auto"></img></div>
	<div class = 'container'>
		<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($i == count($appointments)-1): ?>
		<h3> Dear <?php echo e($appointment->user->name); ?>,</h3>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<p>
			<h4>Greetings!</h4>
			<h4>This is to inform you that your booking request has been received.</h4>
			<h4>The information you sent to us is as follows:</h4>
		</p>
		<p>
			<table class="table table-hover table-stripped">
				<thead>
					<tr>Your Appointment Details
					</tr> 
				</thead>
				<tbody>
					<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($i == count($appointments)-1): ?>
					<tr class="success">
						<td>Date</td>
						<td><?php echo e($appointment->selected_date); ?></td>
					</tr>
					<tr class="success">
						<td>Time</td>
						<td><?php echo e($appointment->selected_start_time); ?> to <?php echo e($appointment->selected_end_time); ?></td>
						<tr>
							<tr class="success">
								<td>Doctor</td>
								<td><?php echo e($appointment->doctor->name); ?></td>
							</tr>
							<tr class="success">
								<td>Service</td>
								<td><?php echo e($appointment->services->service_name); ?></td>
							</tr>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</p>
				<p>
					If you have any questions prior to your visit, we’d be happy to answer them. 
					<br>There are several ways you can get in touch with us.
					<br>We are always available by e-mail at happycliniqe@gmail.com or you can give us a call at 0927 3197000/ 02 616 1601. 
					<br>We also have a very detailed website. Please visit us at www.happyclinique.com.
					<br>
					<h4>Thank you for booking with us!</h4>
				</p>
			</div>
		</body>
		</html>
