<?php

use Illuminate\Database\Seeder;

class ServicesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('services')->insert([
        	'service_name' => 'initial checkup',
        	'service_duration' => '00:30',
        	'specialization_id' => '1',
            'appointment_id' => '1',
        	]);
        DB::table('services')->insert([
        	'service_name' => 'initial checkup',
        	'service_duration' => '00:30',
        	'specialization_id' => '2',
            'appointment_id' => '4',
        	]);
        DB::table('services')->insert([
        	'service_name' => 'oral prophylaxis',
        	'service_duration' => '00:30',
        	'specialization_id' => '1',
            'appointment_id' => '5',
        	]);
        DB::table('services')->insert([
        	'service_name' => 'tooth extraction',
        	'service_duration' => '00:30',
        	'specialization_id' => '1',
            'appointment_id' => '2',
        	]);
        DB::table('services')->insert([
        	'service_name' => 'oxygenating facial',
        	'service_duration' => '01:00',
        	'specialization_id' => '2',
            'appointment_id' => '6',
        	]);
        DB::table('services')->insert([
        	'service_name' => 'installation of braces',
        	'service_duration' => '01:00',
        	'specialization_id' => '1',
            'appointment_id' => '3',
        	]);
    }
}
