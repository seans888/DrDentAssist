<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
        	'name' =>'Reimarie Quirante',
        	'email' =>'rcdelarosa@gmail.com',
        	'password' =>bcrypt('123456'),
        	'appointment_id' =>'1',
        	]);
    }
}
