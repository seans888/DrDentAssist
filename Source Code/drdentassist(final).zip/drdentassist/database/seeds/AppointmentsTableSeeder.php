<?php

use Illuminate\Database\Seeder;

class AppointmentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('appointments')->insert([
            'selected_date' => '2017-09-04',
            'selected_start_time' => '17:30:00',
            'selected_end_time' => '17:30:00',
            'service_id' => '1',
            'schedule_id' => '1',
            'id' => '1',
            'doctor_id'=> '1'
        ]);

         DB::table('appointments')->insert([
            'selected_date' => '2017-08-29',
            'selected_start_time' => '14:00',
            'selected_end_time' => '14:30',
            'service_id' => '4',
            'schedule_id' => '2',
            'id' => '1',
            'doctor_id'=> '2'
        ]);

         DB::table('appointments')->insert([
            'selected_date' => '2017-08-30',
            'selected_start_time' => '11:30:00',
            'selected_end_time' => '12:00:00',
            'service_id' => '6',
            'schedule_id' => '3',
            'id' => '1',
            'doctor_id'=> '3'
        ]);
     }
}
