<?php

use Illuminate\Database\Seeder;

class DoctorSchedulesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('doctor_schedules')->insert([
        	'days_of_the_week' => 'Monday',
        	'start_time' => '17:30:00',
        	'end_time' => '21:00:00',
        	'doctor_id'=>'1',
            'appointment_id'=>'1',
        	]);
        DB::table('doctor_schedules')->insert([
        	'days_of_the_week' => 'Tuesday',
        	'start_time' => '13:00:00',
        	'end_time' => '19:00:00',
        	'doctor_id'=>'2',
            'appointment_id'=>'2',
        	]);
        DB::table('doctor_schedules')->insert([
        	'days_of_the_week' => 'Wednesday',
        	'start_time' => '9:00:00',
        	'end_time' => '12:00:00',
        	'doctor_id'=>'3',
            'appointment_id'=>'3',
        	]);
    }
}
