<?php

use Illuminate\Database\Seeder;

class DoctorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('doctors')->insert([
        	'name' => 'Leticia Aspiras',
        	'email' =>'rcdelarosa@gmail.com',
        	'password' => bcrypt('123456'),
            'specialization_id' => '1',
            'schedule_id' => '1',
            'appointment_id' => '1',
        	]);
        DB::table('doctors')->insert([
        	'name' => 'Nancy Calimag',
        	'email' =>'kristina.punla@gmail.com',
        	'password' =>bcrypt('123456'),
            'specialization_id' => '1',
            'schedule_id' => '2',
            'appointment_id' => '2',
        	]);
        DB::table('doctors')->insert([
        	'name' => 'Elize Estrada',
        	'email' =>'rdquirante@student.apc.edu.ph',
        	'password' =>bcrypt('123456'),
            'specialization_id' => '2',
            'schedule_id' => '3',
            'appointment_id' => '3',
        	]);
    }
}
