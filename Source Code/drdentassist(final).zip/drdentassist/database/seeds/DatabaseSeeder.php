<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use App\Admin;
use App\User;
use App\Specialization;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        Model::unguard();

        DB::table('admins')->delete();

        $admins = array(
            [
                'name' => 'Glenn Anthony',
                'email' => 'rcdelarosa@gmail.com',
                'password' => bcrypt('12345678')],
             );
            
        // Loop through each user above and create the record for them in the database
        foreach ($admins as $admin)
        {
            $admin = Admin::create($admin);
        }

        DB::table('users')->delete();

        $users = array(
            [   'name' => 'Princess',
                'email' => 'rcdelarosa@gmail.com',
                'password' => bcrypt('123456'),
                'phone_number' => '09052717418',
                ],
            [   'name' => 'Tinky',
                'email' => 'tinky.punla@gmail.com',
                'password' => bcrypt('123456'),
                'phone_number' => '09052717418',
                ],
             );
            
        // Loop through each user above and create the record for them in the database
        foreach ($users as $user)
        {
            $user = User::create($user);
        }

        DB::table('specializations')->delete();

        $specializations = array(
            [
            'specialization_name' => 'Dentistry',
            ],

            [
            'specialization_name' => 'Dermatology',
            ]);
            
        // Loop through each user above and create the record for them in the database
        foreach ($specializations as $specialization)
        {
            $specialization = Specialization::create($specialization);
        }

        Model::reguard();
    }
}
