<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class AdminTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('admins')->insert([
            'name' => 'Reimarie Quirante',
            'email' => 'rcdelarosa@gmail.com',
            'password' => bcrypt('123456')
        ]);
        DB::table('admins')->insert([
            'name' => 'Tinky Punla',
            'email' => 'kristina.punla@gmail.com',
            'password' => bcrypt('123456')
        ]);
    }
}
