<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Happy Clinique</title>

    <!-- Styles -->
    
    <!-- Bootstrap Core CSS -->
    
    <link href="{{ asset('font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/jquery.dropdown.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/jquery-ui.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/material-icons.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

    
    </head>


<body>
    <div id="app">
        @include('doctor.layouts._doctornav')
        @include('inc.messages')
        @yield('content')
    </div>

    <script src="{{ asset('js/jquery.js') }}"></script>
    <script src="{{ asset('js/jquery-ui.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/jquery.validate.min.js') }}"></script>

    <!-- bootstrap datepicker -->
    <script type="text/javascript" src="{{ asset('css/moment/min/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('css/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}" ></script>
    <link rel="stylesheet" href="{{ asset('css/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" />

    @yield('javascripts')

</body>
@include('layouts.partials._footer')
</html>