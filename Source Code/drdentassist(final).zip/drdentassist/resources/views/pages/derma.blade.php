@extends('layouts.app')
@section('content')
This is the dermatology page.
@endsection