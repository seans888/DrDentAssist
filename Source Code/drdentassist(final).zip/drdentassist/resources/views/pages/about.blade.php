@extends('layouts.app')
@section('content')
This is the about page.
@endsection
