<%-- 
    Document   : welcome
    Created on : 07 30, 17, 4:34:31 AM
    Author     : chloetanada
--%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta charset="utf-8">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/login.css"> 
        <link rel="stylesheet" href="fonts/glyphicons-halflings-regular.woff">     

    <title>DrDentAssist</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/small-business.css" rel="stylesheet">
</head>
<body>
<%@ page import="authentication.*" %>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
                        <div class="logo">
                            <img src="images/hapi.png" alt="" draggable="false" >
                        </div>  
            </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="services.html">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                    
                </ul>
                <ul class="nav navbar-nav">
                    <li>
                        <a align="right" href="index.html">Logout</a>
                    </li>
                </ul>
                
                        </div>
        </div>
    </nav>
    

    <div class="container">

        
        <div class="row">
            
                <h1>Welcome to Happy Clinique!</h1>
            
        </div>
        
        <hr>
        
        <div class="row">
            
            <div class="col-md-4">
                <img class="img-responsive img-rounded" src="" alt="">
                <h2>Appointments</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</p>
                <a class="btn btn-default" href="#">More Info</a>
            </div>
            
            <div class="col-md-4">
                <img class="img-responsive img-rounded" src="" alt="">
                <h2>History</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</p>
                <a class="btn btn-default" href="#">More Info</a>
            </div>
            
            <div class="col-md-4">
                <img class="img-responsive img-rounded" src="" alt="">
                <h2>Survey</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</p>
                <a class="btn btn-default" href="#">More Info</a>
            </div>
        </div>
        
        <footer>
            <div class="row">
                <div class="col-lg-12" align = "center">
                    <br><br><br><br><p>Copyright &copy; Happy Clinique 2017</p>
                </div>
            </div>
            
        </footer>

    </div>


    <script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>

</body>

</html>