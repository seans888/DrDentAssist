<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Happy Clinique</title>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
 
    <link href="{{ asset('font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/jquery.dropdown.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/jquery-ui.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/material-icons.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/heroic-features.css') }}" rel="stylesheet">

</head>
<body id="page-top" class="index">
        @include('layouts.partials._navigation')
        <div class="container">
    
        @yield('content')
        </div>
    
        @include('layouts.partials._footer')
    <script src="{{ asset('js/jquery.js') }}"></script>
    <script src="{{ asset('js/jquery-ui.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/jquery.validate.min.js') }}"></script>

    <!-- bootstrap datepicker -->
    <script type="text/javascript" src="{{ asset('css/moment/min/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('css/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}" ></script>
    <link rel="stylesheet" href="{{ asset('css/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" />

    @yield('javascripts')
</script>
    </body>
</html>
