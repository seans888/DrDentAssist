@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Edit Service</h1>
		<br>
		
		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::model($services, array('method' => 'PATCH', 'route' => array('services.update', $services->id))) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Service Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('service_name') ? ' has-error' : '' }}">
							<label class="control-label">Service Name</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('service_name', old('service_name'), array('class' => 'form-control', 'placeholder' => 'Service Name')) !!}
							@if ($errors->has('service_name'))
								<span class="error">
									<strong>{{ $errors->first('service_name') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('service_duration') ? ' has-error' : '' }}">
							<label class="control-label">Service Duration</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('service_duration', old('service_duration'), array('class' => 'form-control', 'placeholder' => 'Service_duration')) !!}
							@if ($errors->has('service_duration'))
								<span class="error">
									<strong>{{ $errors->first('service_duration') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('specialization_id') ? ' has-error' : '' }}">
							<label class="control-label">Specialization</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('specialization_id', $specializations->pluck('specialization_name','id'), old('specialization_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('specialization_id'))
								<span class="error">
									<strong>{{ $errors->first('specialization_id') }}</strong>
								</span>
							@endif
						</div>
					</div>


				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('services.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop