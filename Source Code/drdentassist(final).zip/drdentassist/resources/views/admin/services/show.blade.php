@extends('admin.layouts.app')

@section('content')

<div class="container" role="main">
		
		<h1>List of Specialization</h1>

		@if(Session::has('message'))
			<div class="alert alert-dismissible alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>{{ Session::get('message') }}</strong>
			</div>
		@endif
			
		<table class="table table-hover table-stripped">
			<thead>
				<tr>
					<th>ID</th>
					<th>NAME</th>
					<th style="text-align: center;">SERVICES</th>
					<th style="text-align: center;">Edit</th>
					<th style="text-align: center;">Delete</th>
				</tr>
			</thead>
			<tbody>
				@foreach($specializations as $specialization)
				
					
					<tr class="success">
						
						<td>{{ $specialization->id }}</td>
						<td>{{ $specialization->specialization_name }}</td>
						<td style="text-align: center;"><a href="{{ route('services.show', $specialization->service_id) }}"><i class="fa fa-medkit fa-lg"></a></td>
						<td style="text-align: center;"><a href="{{ route('specializations.edit', $specialization->id) }}"><i class="fa fa-edit fa-lg"></a></td>
						<td>
							{!! Form::open(array('method' => 'DELETE', 'route' => array('specializations.destroy', $specialization->id))) !!}
								<a href="#" class="delete">
									<center><i class="fa fa-trash fa-lg"></i></center>
								</a>
								<!-- <button class="btn-link btn-primary delete">
									<i class="fa fa-trash fa-lg"></i>
								</button> -->

								<!-- Modal -->
								<div class="modal fade myModal" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Delete Specialization</h4>
											</div>
											<div class="modal-body">
												<div class="container">
													<div class="row">
														Are you sure you want to delete this specialization?
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary">Delete</button>
												<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
											</div>
										</div>

									</div>
								</div>
							{!! Form::close() !!}
						</td>
					</tr>
			
				@endforeach
			</tbody>
		</table>

		


		<a class="btn btn-raised btn-primary" href="{{ route('specializations.create') }}">Add New Specialization</a>

	</div>

@stop

@section('javascripts')

	<script type="text/javascript">

		$(document).ready(function(){


			$('.delete').click(function(e){

				e.preventDefault();

				$(this).next().modal('show');

			});

			$('.alert-success').fadeTo(2000, 500).slideUp(500, function(){
			    $('.alert-success').slideUp(500);
			});

		});

	</script>

@endsection