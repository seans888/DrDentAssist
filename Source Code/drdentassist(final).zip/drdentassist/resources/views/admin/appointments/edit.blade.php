@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Edit Appointment</h1>
		<br>

		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::model($appointments, array('method' => 'PATCH', 'route' => array('appointments.update', $appointments->id))) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Appointment Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('user_id') ? ' has-error' : '' }}">
							<label class="control-label">Patient</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('user_id', $users->pluck('name','id'), old('user_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('user_id'))
								<span class="error">
									<strong>{{ $errors->first('user_id') }}</strong>
								</span>
							@endif
						</div>
					</div>


					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('doctor_id') ? ' has-error' : '' }}">
							<label class="control-label">Doctor</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('doctor_id', $doctors->pluck('name','id'), old('doctor_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('doctor_id'))
								<span class="error">
									<strong>{{ $errors->first('doctor_id') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('service_id') ? ' has-error' : '' }}">
							<label class="control-label">Service</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('service_id', $services->pluck('service_name','id'), old('service_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('service_id'))
								<span class="error">
									<strong>{{ $errors->first('service_id') }}</strong>
								</span>
							@endif
						</div>
					</div>


					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('selected_date') ? ' has-error' : '' }}">
							<label class="control-label">Date</label>
							<span class="required-asterisk"> *</span>
							{!! Form::date('selected_date', old('selected_date'), array('class' => 'form-control', 'placeholder' => 'mm/dd/yy')) !!}
							@if ($errors->has('selected_date'))
								<span class="error">
									<strong>{{ $errors->first('selected_date') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('selected_start_time') ? ' has-error' : '' }}">
							<label class="control-label">Start Time</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('start_time', old('start_time'), array('class' => 'form-control', 'placeholder' => 'Start Time')) !!}
							@if ($errors->has('start_time'))
								<span class="error">
									<strong>{{ $errors->first('start_time') }}</strong>
								</span>
							@endif
						</div>
					</div>

				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('appointments.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop