@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Edit Schedule</h1>
		<br>

		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::model($schedules, array('method' => 'PATCH', 'route' => array('schedules.update', $schedules->id))) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Schedule Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('days_of_the_week') ? ' has-error' : '' }}">
							<label class="control-label">Day of the Week</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('days_of_the_week', old('days_of_the_week'), array('class' => 'form-control', 'placeholder' => 'Day of the Week')) !!}
							@if ($errors->has('days_of_the_week'))
								<span class="error">
									<strong>{{ $errors->first('days_of_the_week') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('start_time') ? ' has-error' : '' }}">
							<label class="control-label">Start Time</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('start_time', old('start_time'), array('class' => 'form-control', 'placeholder' => 'Start Time')) !!}
							@if ($errors->has('start_time'))
								<span class="error">
									<strong>{{ $errors->first('start_time') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('specialization_id') ? ' has-error' : '' }}">
							<label class="control-label">Specialization</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('specialization_id', $specializations->pluck('specialization_name','id'), old('specialization_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('specialization_id'))
								<span class="error">
									<strong>{{ $errors->first('specialization_id') }}</strong>
								</span>
							@endif
						</div>
					</div>


				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('schedules.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop