@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Add New Schedule</h1>
		<br>

		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::open(array('method' => 'POST', 'route' => 'schedules.store')) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Schedule Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('days_of_the_week') ? ' has-error' : '' }}">
							<label class="control-label">Day of the Week</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('days_of_the_week', old('days_of_the_week'), array('class' => 'form-control', 'placeholder' => 'Day of the Week')) !!}
							@if ($errors->has('days_of_the_week'))
								<span class="error">
									<strong>{{ $errors->first('days_of_the_week') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('start_time') ? ' has-error' : '' }}">
							<label class="control-label">Start Time</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('start_time', old('start_time'), array('class' => 'form-control', 'placeholder' => 'From')) !!}
							@if ($errors->has('start_time'))
								<span class="error">
									<strong>{{ $errors->first('start_time') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('end_time') ? ' has-error' : '' }}">
							<label class="control-label">End Time</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('end_time', old('start_time'), array('class' => 'form-control', 'placeholder' => 'To')) !!}
							@if ($errors->has('end_time'))
								<span class="error">
									<strong>{{ $errors->first('end_time') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('doctor_id') ? ' has-error' : '' }}">
							<label class="control-label">Doctor Name</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('doctor_id', $doctors->pluck('name','id'), old('doctor_id'), array('class' => 'form-control', 'placeholder' => '----'))!!}
							@if ($errors->has('doctor_id'))
								<span class="error">
									<strong>{{ $errors->first('doctor_id') }}</strong>
								</span>
							@endif
						</div>
					</div>


				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('schedules.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop