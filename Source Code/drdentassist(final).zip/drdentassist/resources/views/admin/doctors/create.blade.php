@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Add New Doctor</h1>
		<br>

		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::open(array('method' => 'POST', 'route' => 'doctors.store')) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Doctor Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('name') ? ' has-error' : '' }}">
							<label class="control-label">Doctor Name</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('name', old('name'), array('class' => 'form-control', 'placeholder' => 'Doctor Name')) !!}
							@if ($errors->has('name'))
								<span class="error">
									<strong>{{ $errors->first('name') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('email') ? ' has-error' : '' }}">
							<label class="control-label">Email Address</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('email', old('email'), array('class' => 'form-control', 'placeholder' => 'Email')) !!}
							@if ($errors->has('email'))
								<span class="error">
									<strong>{{ $errors->first('email') }}</strong>
								</span>
							@endif
						</div>
					</div>


					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('password') ? ' has-error' : '' }}">
							<label class="control-label">Password</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('password', old('password'), array('class' => 'form-control', 'placeholder' => 'Password')) !!}
							@if ($errors->has('password'))
								<span class="error">
									<strong>{{ $errors->first('password') }}</strong>
								</span>
							@endif
						</div>
					</div>

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('specialization_id') ? ' has-error' : '' }}">
							<label class="control-label">Specialization</label>
							<span class="required-asterisk"> *</span>
							{!! Form::select('specialization_id', $specializations->pluck('specialization_name','id'), old('specialization_id'), array('class' => 'form-control', 'placeholder' => '--Select Specialization--')) !!}
							@if ($errors->has('specialization_id'))
								<span class="error">
									<strong>{{ $errors->first('specialization_id') }}</strong>
								</span>
							@endif
						</div>
					</div>

				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('doctors.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop