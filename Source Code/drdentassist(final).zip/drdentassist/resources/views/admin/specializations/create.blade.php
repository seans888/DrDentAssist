@extends('admin.layouts.app')

@section('content')

	<!-- start container -->
	<div class="container" role="main">

		<h1>Add New Specialization</h1>
		<br>

		@if(count($errors))
			<div class="alert alert-danger" role="alert">
				<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				<span class="sr-only">Error:</span>
				Please review information that you have entered.
			</div>
		@endif

		<!-- start form -->
		{!! Form::open(array('method' => 'POST', 'route' => 'specializations.store')) !!}

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Specialization Information</h3>
				</div>
				<div class="panel-body">

					<div class="row">
						<div class="form-group col-lg-12 {{ $errors->has('specialization_name') ? ' has-error' : '' }}">
							<label class="control-label">Specialization Name</label>
							<span class="required-asterisk"> *</span>
							{!! Form::text('specialization_name', old('specialization_name'), array('class' => 'form-control', 'placeholder' => 'Specialization Name')) !!}
							@if ($errors->has('specialization_name'))
								<span class="error">
									<strong>{{ $errors->first('specialization_name') }}</strong>
								</span>
							@endif
						</div>
					</div>

				</div>
			</div>

			<button type="submit" class="btn btn-raised btn-primary">Save</button>

			<a class="btn btn-raised btn-primary" href="{{ route('specializations.index') }}">Back</a>

		<!-- end form-->
		{!! Form::close() !!}

	<!-- end container -->
	</div>
	<!-- end content block -->
@stop