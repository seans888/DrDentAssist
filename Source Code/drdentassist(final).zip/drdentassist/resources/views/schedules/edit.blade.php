@extends('admin.layouts.app')

@section('content')
<div class = "container">
	<h1>Edit Schedule</h1>
	{!! Form::open(['action' => ['SchedulesController@update', $schedule->schedule],'method' => 'POST']) !!}
					<div class="form-group">
					{{ Form::hidden('doctor_id', $schedule->doctor_id, ['class' => 'form-control']) }}
					<h3>{{$schedule->doctor->name}}</h3>
				</div>
		<div class="form-group">
				   {{ Form::label('days_of_the_week', 'Edit Day')}}
					{{ Form::select('days_of_the_week', [
					'Monday' => 'Monday',
					'Tuesday' => 'Tuesday',
					'Wednesday' => 'Wednesday',
					'Thursday' => 'Thursday',
					'Friday' => 'Friday',
					'Saturday' => 'Saturday']
					) }}
		</div>
		<div class="form-group">
			{{Form::label('start_time', 'Start_Time')}}
			{{Form::text('start_time', $schedule->start_time, ['class' => 'timepicker form-control', 'placeholder' => 'Start Time'])}}
		</div>
		<div class="form-group">
			{{Form::label('end_time', 'End_Time')}}
			{{Form::text('end_time', $schedule->end_time, ['class' => 'timepicker form-control', 'placeholder' => 'End Time'])}}
		</div>
	   {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}	
	{!! Form::close() !!}
</div>
@endsection