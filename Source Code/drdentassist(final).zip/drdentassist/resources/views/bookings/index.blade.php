@extends('layouts.app')

@section('content')


	<div class="container" role="main">
		
		<h1>My Appointments</h1>

		@if(Session::has('message'))
			<div class="alert alert-dismissible alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>{{ Session::get('message') }}</strong>
			</div>
		@endif
		<table class="table table-hover table-stripped" >
			<thead>
				<tr>
					<th>ID</th>
					<th>Doctor Name</th>
					<th>Service</th>
					<th>Appointment Date</th>
					<th>Appointment Time</th>
					<th style="text-align: center;">Delete</th>
				</tr>	
			</thead>
			<tbody>

				@foreach($appointments as $appointment)
					@if(Auth::user()->id == $appointment->user_id)
					<tr class="success">
						<td>{{ $appointment->id }}</td>
						<td>{{ $appointment->doctor->name }}</td>
						<td>{{ $appointment->services->service_name }}</td>
						<td>{{ $appointment->selected_date}}</td>
						<td>{{ $appointment->selected_start_time }} to {{ $appointment->selected_end_time }}</td>										
						<td>
							{!! Form::open(array('method' => 'DELETE', 'route' => array('appointments.destroy', $appointment->id))) !!}
								<a href="#" class="delete">
									<center><i class="fa fa-trash fa-lg"></i></center>
								</a>
								<!-- <button class="btn-link btn-primary delete">
									<i class="fa fa-trash fa-lg"></i>
								</button> -->

								<!-- Modal -->
								<div class="modal fade myModal" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Delete Appointment</h4>
											</div>
											<div class="modal-body">
												<div class="container">
													<div class="row">
														Are you sure you want to delete this appointment?
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary">Delete</button>
												<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
											</div>
										</div>

									</div>
								</div>
							{!! Form::close() !!}
						</td>
					</tr>
					@endif
				@endforeach
			</tbody>
		</table>

		{{ $appointments->links() }}


		<a class="btn btn-raised btn-primary" href="{{ route('bookings.create') }}">Add New Appointment</a>

	</div>

@stop

@section('javascripts')

	<script type="text/javascript">

		$(document).ready(function(){


			$('.delete').click(function(e){

				e.preventDefault();

				$(this).next().modal('show');

			});

			$('.alert-success').fadeTo(2000, 500).slideUp(500, function(){
			    $('.alert-success').slideUp(500);
			});

		});

	</script>

@endsection



		

