<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'selected_date', 'selected_start_time', 'selected_end_time',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     *
    *protected $hidden = [
    *   'password', 'remember_token',
    *];
    */

    public function doctor(){
        return $this->belongsTo('App\Doctors', 'doctor_id');
    }

    public function services(){
        return $this->belongsTo('App\Services', 'service_id');
    }

    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }

}
