<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
    protected $fillable = [
        'service_name', 'service_duration',
    ];
  
     public function specialization(){
        return $this->belongsTo('App\Specialization', 'specialization_id')->withDefault();
    }

  

}
