<?php

namespace App\Http\Controllers\User;

use Illuminate\Contracts\View\View;
use App\User;
use App\Http\Controllers\Controller;
use App\Http\Controllers\AuthenticatesUsers;

use \App, \Session, \Validator, \Request, \Redirect, \Auth;

class AuthUserController extends Controller
{
    
    use AuthenticatesUsers;
    
    protected $guard = 'web';
    protected $redirectTo = '/';

    public function get_login()
    {

        return view('auth.login');

    }


    public function get_register()
    {

       
        return view('auth.register');

    }

    public function post_register(Request $request)
    {

        $name = Request::input('name');
        $phone_number = Request::input('phone_number');
        $email = Request::input('email');        
        $password = Request::input('password');

        $validator = Validator::make(
            Request::all(),
            array(
                'name' => 'required',
                'phone_number' => 'required',
                'email' => 'required',
                'password' => 'required|min:6|confirmed',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{
            $users = new User();
            $users->name = $name;
            $users->phone_number = $phone_number;
            $users->email = $email;
            $users->password = bcrypt($password);

            $users->save();


            Auth::guard('web')->login($users);

            Session::flash('status' ,'Congratulation you are now registered.');

            return redirect('/');

        }

    }
}

