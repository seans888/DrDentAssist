<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;

use \Request, \Redirect, \Validator, \Session, \Response;

use App\Appointment;
use App\Doctors;   
use App\Services;
use App\Schedules;
use App\User;


class AppointmentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $appointments = Appointment::paginate(15);

        return view('patient.appointments.index')->with('appointments', $appointments);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $doctors = Doctors::all();
        $schedules = Schedules::all();
        $services = Services::all();
        $users = User::all();

        return view('patient.appointments.create')->with('doctors', $doctors)
            ->with('schedules', $schedules)->with('services', $services)->with('users', $users);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $selected_date = Request::input('selected_date');
        $selected_start_time = Request::input('selected_start_time');
        $selected_end_time = Request::input('selected_end_time');
        $doctor_id = Request::input('doctor_id');
        $schedule_id = Request::input('schedule_id');
        $service_id = Request::input('service_id');
        
      
        $user_id = Request::input (Auth::user()->id);
       

        $validator = Validator::make(
            Request::all(),
            array(
                'selected_date' => 'required',
                'selected_start_time' => 'required',
                'selected_end_time' => 'required',
                'doctor_id' => 'required',
                'schedule_id' => 'required',
                'service_id' => 'required',
                'user_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $appointments = new Appointment();

            $appointments->selected_date = $selected_date;

            $appointments->selected_start_time = $selected_start_time;

            $appointments->selected_end_time = $selected_end_time;

            $appointments->doctor_id = $doctor_id;

            $appointments->schedule_id = $schedule_id;

            $appointments->service_id = $service_id;

            $appointments->user_id = $user_id;

            $appointments->save();

            Session::flash('message', 'Appointment saved!');

            return Redirect::route('appointments.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $appointments = Appointment::find($id);
        $doctors = Doctors::all();
        $schedules = Schedules::all();
        $services = Services::all();
        $users = User::all();

        return view('patient.appointments.edit')->with('doctors', $doctors)
            ->with('schedules', $schedules)->with('services', $services)->with('users', $users);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $selected_date = Request::input('selected_date');
        $selected_start_time = Request::input('selected_start_time');
        $selected_end_time = Request::input('selected_end_time');
        $doctor_id = Request::input('doctor_id');
        $schedule_id = Request::input('schedule_id');
        $service_id = Request::input('service_id');

        $user_id = Request::input (Auth::user()->id);

        $validator = Validator::make(
            Request::all(),
            array(
                'selected_date' => 'required',
                'selected_start_time' => 'required',
                'selected_end_time' => 'required',
                'doctor_id' => 'required',
                'schedule_id' => 'required',
                'service_id' => 'required',
                'user_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $appointments = Appointment::find($id);

            $appointments->selected_date = $selected_date;

            $appointments->selected_start_time = $selected_start_time;

            $appointments->selected_end_time = $selected_end_time;

            $appointments->doctor_id = $doctor_id;

            $appointments->schedule_id = $schedule_id;

            $appointments->service_id = $service_id;

            $appointments->user_id = $user_id;

            $appointments->save();

            Session::flash('message', 'Appointment updated!');

            return Redirect::route('appointments.index');

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        Appointment::destroy($id);
        
        Session::flash('message', 'Appointment deleted!');

        return Redirect::route('appointments.index');

    }
}
