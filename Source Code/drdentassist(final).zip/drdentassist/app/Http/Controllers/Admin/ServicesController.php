<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use \Request, \Redirect, \Validator, \Session, \Response;

use App\Services;

use App\Specialization;

class ServicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $services = Services::paginate(15);

        return view('admin.services.index')->with('services', $services);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $specializations = Specialization::all();

        return view('admin.services.create')->with('specializations', $specializations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $service_name = Request::input('service_name');
        $service_duration = Request::input('service_duration');
        $specialization_id = Request::input('specialization_id');

        $validator = Validator::make(
            Request::all(),
            array(
                'service_name' => 'required',
                'service_duration' => 'required',
                'specialization_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $services = new Services();

            $services->service_name = $service_name;

            $services->service_duration = $service_duration;

            $services->specialization_id = $specialization_id;

            $services->save();

            Session::flash('message', 'Services saved!');

         
            return Redirect::route('services.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $services = Services::find($id);
        $specializations = Specialization::all();

        return view('admin.services.edit')->with('services', $services)->with('specializations', $specializations);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $service_name = Request::input('service_name');
        $service_duration = Request::input('service_duration');
        $specialization_id = Request::input('specialization_id');

        $validator = Validator::make(
            Request::all(),
            array(
                'service_name' => 'required',
                'service_duration' => 'required',
                'specialization_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $services = Services::find($id);

            $services->service_name = $service_name;

            $services->service_duration = $service_duration;

            $services->specialization_id = $specialization_id;

            $services->save();

            Session::flash('message', 'Services updated!');

            return Redirect::route('services.index');

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        Services::destroy($id);
        
        Session::flash('message', 'Service deleted!');

        return Redirect::route('services.index');

    }
}
