<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Contracts\View\View;

use App\Http\Controllers\Controller;
use App\Http\Controllers\AuthenticatesUsers;

use \App, \Session, \Validator, \Request, \Redirect, \Auth;

class AuthAdminController extends Controller
{
    
    use AuthenticatesUsers;
    
    protected $guard = 'admin';
    protected $redirectTo = '/admin';

    public function get_login()
    {

        return view('admin.auth.login');

    }


    public function get_register()
    {

        return view('admin.register');

    }

    public function post_register()
    {

        $first_name = Request::input('first_name');
        $middle_name = Request::input('middle_name');
        $last_name = Request::input('last_name');

        $member_card_id = Request::input('member_card_id');
        $upline_id = Request::input('upline_id');
        $sponsor_id = Request::input('sponsor_id');
        $position = Request::input('position');

        $username = Request::input('username');
        $email = Request::input('email');
        $password = Request::input('password');

        $validator = Validator::make(
            Request::all(),
            array(
                'first_name' => 'required',
                'middle_name' => 'required',
                'last_name' => 'required',
                'member_card_id' => 'required',
                'upline_id' => 'required',
                'sponsor_id' => 'required',
                'position' => 'required',
                'username' => 'required|min:6|unique:members',
                'password' => 'required|min:6|confirmed',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $member_card_id = MemberCard::where('member_id', '=', $member_card_id)->first();
            $upline = Member::find($upline_id);
            $sponsor = Member::find($sponsor_id);

            if(!$member_card_id){
                return Redirect::back()
                    ->withErrors(['error' => 'Member Card ID does not exist!'])->withInput();
            }
            if(!$upline){
                return Redirect::back()
                    ->withErrors(['error' => 'Upline ID does not exist!'])->withInput();
            }
            elseif($upline->left_id && $position == 'Left Leg'){
                return Redirect::back()
                    ->withErrors(['error' => 'Position already occupied'])->withInput();
            }

            if(!$sponsor){
                return Redirect::back()
                ->withErrors(['error' => 'Sponsor ID does not exist!'])->withInput();
            }
            elseif($upline->right_id && $position == 'Right Leg'){
                return Redirect::back()
                    ->withErrors(['error' => 'Position already occupied'])->withInput();
            }

            $members = new Member();

            $members->first_name = $first_name;
            $members->middle_name = $middle_name;
            $members->last_name = $last_name;

            $members->username = $username;
            $members->password = bcrypt($password);

            $members->member_card_id = $member_card_id->id;
            $members->upline_id = $upline_id;
            $members->sponsor_id = $sponsor_id;
            $members->position = $position;

            $members->save();

            if($position == 'Left Leg'){
                $upline->left_id = $members->id;

                $upline->save();
            }
            elseif($position == 'Right Leg'){
                $upline->right_id = $members->id;

                $upline->save();
            }

            Auth::guard('members')->login($members);

            Session::flash('status' ,'Congratulation you are now registered.');

            return redirect('/');

        }

    }


}
