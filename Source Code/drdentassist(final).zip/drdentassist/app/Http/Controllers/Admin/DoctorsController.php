<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use \Request, \Redirect, \Validator, \Session, \Response;

use App\Doctors;
    
use App\Specialization;

class DoctorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $doctors = Doctors::paginate(15);

        return view('admin.doctors.index')->with('doctors', $doctors);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $specializations = Specialization::all();

        return view('admin.doctors.create')->with('specializations', $specializations);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $name = Request::input('name');
        $email = Request::input('email');
        $password = Request::input('password');
        $specialization_id = Request::input('specialization_id');

        $validator = Validator::make(
            Request::all(),
            array(
                'name' => 'required',
                'email' => 'required',
                'password' => 'required',
                'specialization_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $doctors = new Doctors();

            $doctors->name = $name;

            $doctors->email = $email;

            $doctors->password = $password;

            $doctors->specialization_id = $specialization_id;

            $doctors->save();

            Session::flash('message', 'Doctor saved!');

            return Redirect::route('doctors.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $doctor = Doctors::find($id);
        $specializations = Specialization::all();
        return view('admin.doctors.edit')->with('doctor', $doctor)->with('specializations', $specializations);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $name = Request::input('name');
        $email = Request::input('email');
        $password = Request::input('password');
        $specialization_id = Request::input('specialization_id');

        $validator = Validator::make(
            Request::all(),
            array(
                'name' => 'required',
                'email' => 'required',
                'password' => 'required',
                'specialization_id' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $doctors = Doctors::find($id);

            $doctors->name = $name;

            $doctors->email = $email;

            $doctors->password = $password;

            $doctors->specialization_id = $specialization_id;

            $doctors->save();

            Session::flash('message', 'Doctors updated!');

            return Redirect::route('doctors.index');

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        Doctors::destroy($id);
        
        Session::flash('message', 'Doctor deleted!');

        return Redirect::route('doctors.index');

    }
}
