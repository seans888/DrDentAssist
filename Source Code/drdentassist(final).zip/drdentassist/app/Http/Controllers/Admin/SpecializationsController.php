<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use \Request, \Redirect, \Validator, \Session, \Response;

use App\Specialization;

class SpecializationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $specializations = Specialization::paginate(15);

        return view('admin.specializations.index')->with('specializations', $specializations);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.specializations.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $specialization_name = Request::input('specialization_name');

        $validator = Validator::make(
            Request::all(),
            array(
                'specialization_name' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $specializations = new Specialization();

            $specializations->specialization_name = $specialization_name;

            $specializations->save();

            Session::flash('message', 'Specialization saved!');

            return Redirect::route('specializations.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $specialization = Specialization::find($id);
        
        return view('admin.specializations.edit')->with('specialization', $specialization);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $specialization_name = Request::input('specialization_name');

        $validator = Validator::make(
            Request::all(),
            array(
                'specialization_name' => 'required',
            )
        );

        if($validator->fails()){

            return Redirect::back()
                ->withErrors($validator)->withInput();

        }
        else{

            $specializations = Specialization::find($id);

            $specializations->specialization_name = $specialization_name;

            $specializations->save();

            Session::flash('message', 'Specialization updated!');

            return Redirect::route('specializations.index');

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        Specialization::destroy($id);
        
        Session::flash('message', 'Specialization deleted!');

        return Redirect::route('specializations.index');

    }
}
