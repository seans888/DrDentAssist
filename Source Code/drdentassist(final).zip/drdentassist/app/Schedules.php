<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Schedules extends Model
{
    protected $fillable = [
        'days_of_the_week', 'start_time', 'end_time',
    ];

    public function doctor(){
    	return $this->belongsTo('App\Doctors', 'doctor_id');
    }

}
