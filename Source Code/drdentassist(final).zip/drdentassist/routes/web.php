<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('pages.one');
});*/

Route::get('/', 'PagesController@index');

// Route::get('/about', 'PagesController@about');
Route::get('/services', 'PagesController@services');
// Route::get('/contactus', 'PagesController@contact');
// Route::get('/derma', 'PagesController@derma');
// Route::get('/dental', 'PagesController@dental');
// Route::get('/pages/appointment', 'PagesController@appointment');

Auth::routes();


Route::group([ 'namespace' => 'User'], function () {

    Route::group(['middleware' => ['auth:web']], function ($router) {
        Route::resource('bookings', 'BookingsController');
    });


    Route::get('login', 'AuthUserController@get_login')->name('getLogin');
    Route::post('login', 'AuthUserController@login')->name('login');
    Route::get('register', 'AuthUserController@get_register')->name('getRegister');
    Route::post('register', 'AuthUserController@post_register')->name('register');
    Route::post('logout', 'AuthUserController@logout')->name('logout');
    Route::get('home', 'HomeController@index');
});

Route::group(['prefix' => 'admin', 'namespace' => 'Admin'], function () {
    
    Route::group(['middleware' => ['auth:admin']], function ($router) {

        Route::get('/', 'HomeController@index');

        Route::resource('doctors', 'DoctorsController');
        Route::resource('specializations', 'SpecializationsController');
        Route::resource('services', 'ServicesController');
        Route::resource('schedules', 'SchedulesController');
        Route::resource('appointments', 'AppointmentsController');
    });

    Route::get('login', 'AuthAdminController@get_login')->name('admin.getLogin');
    Route::post('login', 'AuthAdminController@login')->name('admin.login');
    Route::post('logout', 'AuthAdminController@logout')->name('admin.logout');
    Route::get('home', 'HomeController@index');
});

Route::group(['prefix' => 'doctor', 'namespace' => 'Doctor'], function () {
    Route::get('login', 'AuthDoctorController@get_login')->name('doctor.getLogin');
    Route::post('login', 'AuthDoctorController@login')->name('doctor.login');
    Route::post('logout', 'AuthDoctorController@logout')->name('doctor.logout');
    Route::get('home', 'HomeController@index');
});



