$(document).ready(function(){

  /*$('#last_name').autocomplete({
    source: "/customer/autocomplete",
        minLength: 1,
        select: function( event, ui ) {
            $('#last_name').val(ui.item.first_name)
            $( "#first_name" ).val(ui.item.id );
            return false;
        }
    }).data("ui-autocomplete" )._renderItem = function( ul, item ) {
        return $( "<li>" )
            .data( "item.autocomplete-item", item )
            .append( "<a>" + item.id + " - " + item.first_name + "</a>" )
            .appendTo( ul );
    };*/

/*
  $('#last_name').autocomplete({
          source: function(request, response){
              $.ajax({
                  url: '/customer/autocomplete',
                  dataType: "json",
                  minLength: 2,
                  data: {
                      term: request.term
                  },
                  error: function(xhr, textStatus, errorThrown) {
                      alert(errorThrown);
                  },
                  success: function(data){
                      response(data);
                  }
              })
          }
      });
      */

  /* customer model */


    //start bank_accounts
  var bank_accounts_wrapper         = $("#bank_accounts_wrapper"); //Fields wrapper
  var bank_accounts_add_button      = $("#add_bank_accounts"); //Add button ID

  //counter
  var bank_accounts_counter = 1;

    $(bank_accounts_add_button).click(function(e){ //on add input button click
        e.preventDefault();

        var bank_account_form = 
          '<div><!--start div 1-->' +
            '<hr />' +
            '<div class="row">' +
              
              '<div class="form-group col-lg-4">'+
                '<label class="control-label" for="bank_accounts-'+bank_accounts_counter+'-bank_name">Main Bank</label>'+
                '<input class="form-control" id="bank_accounts-'+bank_accounts_counter+'-bank_name" name="bank_accounts-'+bank_accounts_counter+'-bank_name" placeholder="bank name / branch" type="text" value="">'+
              '</div>'+
          
             '<div class="form-group col-lg-3">'+
                '<label class="control-label" for="bank_accounts-'+bank_accounts_counter+'-bank_number">Bank Account Number</label>'+
                '<input class="form-control" id="bank_accounts-'+bank_accounts_counter+'-bank_number" name="bank_accounts-'+bank_accounts_counter+'-bank_number" placeholder="bank account number" type="text" value="">'+
              '</div>'+

             '<div class="form-group col-lg-3">'+
                '<label class="control-label" for="bank_accounts-'+bank_accounts_counter+'-estimated_annual_balance">Estimated Annual Balance</label>'+
                '<input class="form-control" id="bank_accounts-'+bank_accounts_counter+'-estimated_annual_balance" name="bank_accounts-'+bank_accounts_counter+'-estimated_annual_balance" placeholder="estimated annual balance" type="text" value="">'+
              '</div>'+

            '</div>' +
            '<a href="#" id="remove_field" class="btn btn-success btn-raised">Remove</a>';
          '</div>';


        bank_accounts_counter++;
        $(bank_accounts_wrapper).append(bank_account_form); //add input box
    });

    $(bank_accounts_wrapper).on("click","#remove_field", function(e){ //user click on remove text
        e.preventDefault();
        $(this).parent('div').remove();
        bank_accounts_counter--;
    });
  // end banks accounts




  //start crop_details
  var crop_details_wrapper         = $("#crop_details"); //Fields wrapper
  var crop_details_add_button      = $("#add_crop_details"); //Add button ID

  //counter
  var crop_details_counter = 1;

    $(crop_details_add_button).click(function(e){ //on add input button click
        e.preventDefault();

        var crop_details_form = '<div><!--start div 1-->' +
            '<hr />' +
            '<div class="row">' +
              '<div class="col-lg-1">' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-crop">Crop</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-crop" name="farm_details-' + crop_details_counter + '-crop" placeholder="crop" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-1">' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-farm_size">Farm Size</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-farm_size" name="farm_details-' + crop_details_counter + '-farm_size" placeholder="size" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-2">' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-first">1st</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-first" name="farm_details-' + crop_details_counter + '-first" placeholder="1st" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-2">' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-second">2nd</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-second" name="farm_details-' + crop_details_counter + '-second" placeholder="2nd" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-2">' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-third">3rd</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-third" name="farm_details-' + crop_details_counter + '-third" placeholder="3rd" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-2">' +
                '<label class="control-label">Irrigation</label><br>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-fully_irrigated" name="farm_details-' + crop_details_counter + '-fully_irrigated" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-fully_irrigated">Fully irrigated</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-communal" name="farm_details-' + crop_details_counter + '-communal" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-communal">Communal</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-own_pump" name="farm_details-' + crop_details_counter + '-own_pump" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-own_pump">Own pump</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-rainfed" name="farm_details-' + crop_details_counter + '-rainfed" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-rainfed">Rainfed</label>' +
                  '</label>' +
                '</div>' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-irrigation_other">Other</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-irrigation_other" name="farm_details-' + crop_details_counter + '-irrigation_other" placeholder="other irrigation" type="text" value="">' +
                '</div>' +
              '</div>' +
              '<div class="col-lg-2">' +
                '<label class="control-label">Machinery</label><br>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-hand_tractor" name="farm_details-' + crop_details_counter + '-hand_tractor" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-hand_tractor">Hand tractor</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-rotavator" name="farm_details-' + crop_details_counter + '-rotavator" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-rotavator">Rotavator</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-thresher" name="farm_details-' + crop_details_counter + '-thresher" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-thresher">Thresher</label>' +
                  '</label>' +
                '</div>' +
                '<div class="checkbox">' +
                  '<label>' +
                    '<input id="farm_details-' + crop_details_counter + '-combine" name="farm_details-' + crop_details_counter + '-combine" type="checkbox" value="y"><span class="checkbox-material"><span class="check"></span></span><span class="checkbox-material"></span> <label class="control-label" for="farm_details-' + crop_details_counter + '-combine">Combine</label>' +
                  '</label>' +
                '</div>' +
                '<div class="form-group  is-empty">' +
                  '<label class="control-label" for="farm_details-' + crop_details_counter + '-machinery_other">Other</label>' +
                  '<input class="form-control" id="farm_details-' + crop_details_counter + '-machinery_other" name="farm_details-' + crop_details_counter + '-machinery_other" placeholder="other machinery" type="text" value="">' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div class="row">' +
              '<div class="form-group col-lg-4  is-empty">' +
                '<label class="control-label" for="farm_details-' + crop_details_counter + '-planting_to_tillering">Planting to tillering</label>' +
                '<input class="form-control" id="farm_details-' + crop_details_counter + '-planting_to_tillering" name="farm_details-' + crop_details_counter + '-planting_to_tillering" placeholder="planting to tillering" type="text" value="">' +
              '</div>' +
              '<div class="form-group col-lg-4  is-empty">' +
                '<label class="control-label" for="farm_details-' + crop_details_counter + '-vegetative">Vegetative</label>' +
                '<input class="form-control" id="farm_details-' + crop_details_counter + '-vegetative" name="farm_details-' + crop_details_counter + '-vegetative" placeholder="vegetative" type="text" value="">' +
              '</div>' +
              '<div class="form-group col-lg-4  is-empty">' +
                '<label class="control-label" for="farm_details-' + crop_details_counter + '-reproductive_to_ripening">Reproductive to ripening</label>' +
                '<input class="form-control" id="farm_details-' + crop_details_counter + '-reproductive_to_ripening" name="farm_details-' + crop_details_counter + '-reproductive_to_ripening" placeholder="reproductive to ripening" type="text" value="">' +
              '</div>' +
            '</div>' +
            '<a href="#" id="remove_field" class="btn btn-success btn-raised">Remove</a>';
          '</div>';


        crop_details_counter++;
        $(crop_details_wrapper).append(crop_details_form); //add input box
    });

    $(crop_details_wrapper).on("click","#remove_field", function(e){ //user click on remove text
        e.preventDefault();
        $(this).parent('div').remove();
        crop_details_counter--;
    });
  // end crop_details

  //start farm_practice

  $(document).on("keydown.autocomplete","input[name=category_name]",function(e){
    $(this).autocomplete({
      source: "/category/autocomplete",
      minLength: 1,
      select: function( event, ui ) {
        $(this).val(ui.item.name)
        $(this).next('input').val(ui.item.id );
        return false;
      }
      }).data("ui-autocomplete")._renderItem = function( ul, item ) {
        return $( "<li></li>" )
          .data( "item.autocomplete", item )
          .append( "<a>" + item.id + " - " + item.name + "</a>" )
          .appendTo( ul );
    };
  });

  $(document).on("keydown.autocomplete","input[name=brand_name]",function(e){
    $(this).autocomplete({
      source: "/brand/autocomplete",
      minLength: 1,
      select: function( event, ui ) {
        $(this).val(ui.item.name)
        $(this).next('input').val(ui.item.id );
        return false;
      }
      }).data("ui-autocomplete" )._renderItem = function( ul, item ) {
        return $( "<li>" )
          .data( "item.autocomplete-item", item )
          .append( "<a>" + item.id + " - " + item.name + "</a>" )
          .appendTo( ul );
    };
  });

  var farm_practices_wrapper         = $("#farm_practices"); //Fields wrapper
  var farm_practices_add_button      = $("#add_farm_practices"); //Add button ID

  //counter
  var farm_practices_counter = $('#farm_practices >tbody >tr').length;

  $(farm_practices_add_button).click(function(e){ //on add input button click
      e.preventDefault();

      $.ajax({
        url:'/customers/farmers_practice/' + farm_practices_counter,
        context:document.body
      }).done(function(fragment){
        $(farm_practices_wrapper).append(fragment);
      });

      farm_practices_counter++;
  });

  $(farm_practices_wrapper).on("click","#remove_field", function(e){ //user click on remove text
      e.preventDefault();
      $(this).parent().parent().remove();
      farm_practices_counter--;
  });
  // end farm_practice

/* end customer model */


});
