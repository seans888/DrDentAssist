/*global define:false*/

import moment from "./moment";

define("moment", [], function () {
    return moment;
});
