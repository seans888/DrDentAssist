<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
               
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    At Happy Clinique, we are dedicated to providing professional health care to individuals, families and the community.<br>
                    There’s much more to come!
                </div>
                <div>
                    <img src="/images/service1.jpg">
                    <img src="/images/service2.jpg">
                    <img src="/images/service3.jpg">
                    <img src="/images/service4.jpg">
                </div>
            </div>
            <div>
                <a href ="">What we can offer you </a>
            </div><br/>
            <div>
                <a href ="">Who we are and our availability hours</a>
            </div><br/>
            <div>
                <a href ="">We love to hear from you!</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>