 <!-- Header -->
 <header class="jumbotron hero-spacer">
            <h1>A Warm Welcome!</h1>
            <p>At Happy Clinique, we are dedicated to providing professional health care to individuals, families and the community.
There’s much more to come! </p>
            <p><a class="btn btn-primary btn-large">Book an appointment with us!</a>
            </p>
        </header>